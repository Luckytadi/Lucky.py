weight= input("weight: ")
unit = input("(l)lbs or (k)kgs ")
if unit == "l":
    convert=0.45 * float(weight)
    print("you are", convert ,"kilos")
elif unit == "k":
    convert= float(weight) / 0.45
    print("you are", convert ,"pounds")